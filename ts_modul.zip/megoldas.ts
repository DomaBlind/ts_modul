// 1. feladat – SZEKVENCIA
export function MegtettUt(sebesseg: number, ido: number): number {
    return sebesseg * ido;
}

// 2. feladat – SZELEKCIÓ
export function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
    const napok = [nap1, nap2, nap3];
    const mindHaromLegalabb27 = napok.every(h => h >= 27);
    const mindHaromLegalabb25 = napok.every(h => h >= 25);
    const vanLegalabbEgy25 = napok.some(h => h >= 25);

    if (mindHaromLegalabb27) return 3;
    else if (mindHaromLegalabb25) return 2;
    else if (vanLegalabbEgy25) return 1;
    return 0;
}

// 3. feladat – ITERÁCIÓ
export function OszthatoSzamok(oszto: number, vizsgaltTomb: number[]): number {
    return vizsgaltTomb.filter(szam => szam % oszto === 0).length;
}

// 4. feladat – TUPLE (Kör kerület és terület)
export function KorKeruletTerulet(sugar: number): [number, number] {
    const kerulet = +(2 * Math.PI * sugar).toFixed(1);
    const terulet = +(Math.PI * sugar * sugar).toFixed(1);
    return [kerulet, terulet];
}

// 5. feladat – TUPLE (Érettségi értékelés)
export function Erettsegi(pontok: number[]): [number, number] {
    const osszpont = pontok.reduce((sum, pont) => sum + pont, 0);
    let jegy: number;
    if (osszpont < 40) jegy = 1;
    else if (osszpont < 60) jegy = 2;
    else if (osszpont < 80) jegy = 3;
    else if (osszpont < 120) jegy = 4;
    else jegy = 5;
    return [osszpont, jegy];
}

// 6. feladat – SZÖVEGKEZELÉS (Leet kód)
export function LeetKod(vizsgaltSzoveg: string): string {
    return vizsgaltSzoveg
        .replace(/i/gi, "1")
        .replace(/o/gi, "0")
        .replace(/a/gi, "4")
        .replace(/e/gi, "3");
}

// 7. feladat – OBJEKTUM feldolgozás

// Interface
export interface SnookerJatekos {
    helyezes: number;
    nev: string;
    nemzetiseg: string;
    nyeremeny: number;
}

// Objektum feltöltő függvény
export function ObjektumFeltolto(sorok: string[]): SnookerJatekos[] {
    return sorok.map(sor => {
        const [helyezes, nev, nemzetiseg, nyeremeny] = sor.split(";");
        return {
            helyezes: parseInt(helyezes),
            nev,
            nemzetiseg,
            nyeremeny: parseInt(nyeremeny)
        };
    });
}

// Legnagyobb nyeremény visszaadó függvény
export function LegtobbNyeremeny(vizsgaltObjektum: SnookerJatekos[]): number {
    return Math.max(...vizsgaltObjektum.map(jatekos => jatekos.nyeremeny));
}