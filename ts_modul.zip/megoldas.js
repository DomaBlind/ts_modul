"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MegtettUt = MegtettUt;
exports.HosegriadoSzint = HosegriadoSzint;
exports.OszthatoSzamok = OszthatoSzamok;
exports.KorKeruletTerulet = KorKeruletTerulet;
exports.Erettsegi = Erettsegi;
exports.LeetKod = LeetKod;
exports.ObjektumFeltolto = ObjektumFeltolto;
exports.LegtobbNyeremeny = LegtobbNyeremeny;
// 1. feladat – SZEKVENCIA
function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
// 2. feladat – SZELEKCIÓ
function HosegriadoSzint(nap1, nap2, nap3) {
    var napok = [nap1, nap2, nap3];
    var mindHaromLegalabb27 = napok.every(function (h) { return h >= 27; });
    var mindHaromLegalabb25 = napok.every(function (h) { return h >= 25; });
    var vanLegalabbEgy25 = napok.some(function (h) { return h >= 25; });
    if (mindHaromLegalabb27)
        return 3;
    else if (mindHaromLegalabb25)
        return 2;
    else if (vanLegalabbEgy25)
        return 1;
    return 0;
}
// 3. feladat – ITERÁCIÓ
function OszthatoSzamok(oszto, vizsgaltTomb) {
    return vizsgaltTomb.filter(function (szam) { return szam % oszto === 0; }).length;
}
// 4. feladat – TUPLE (Kör kerület és terület)
function KorKeruletTerulet(sugar) {
    var kerulet = +(2 * Math.PI * sugar).toFixed(1);
    var terulet = +(Math.PI * sugar * sugar).toFixed(1);
    return [kerulet, terulet];
}
// 5. feladat – TUPLE (Érettségi értékelés)
function Erettsegi(pontok) {
    var osszpont = pontok.reduce(function (sum, pont) { return sum + pont; }, 0);
    var jegy;
    if (osszpont < 40)
        jegy = 1;
    else if (osszpont < 60)
        jegy = 2;
    else if (osszpont < 80)
        jegy = 3;
    else if (osszpont < 120)
        jegy = 4;
    else
        jegy = 5;
    return [osszpont, jegy];
}
// 6. feladat – SZÖVEGKEZELÉS (Leet kód)
function LeetKod(vizsgaltSzoveg) {
    return vizsgaltSzoveg
        .replace(/i/gi, "1")
        .replace(/o/gi, "0")
        .replace(/a/gi, "4")
        .replace(/e/gi, "3");
}
// Objektum feltöltő függvény
function ObjektumFeltolto(sorok) {
    return sorok.map(function (sor) {
        var _a = sor.split(";"), helyezes = _a[0], nev = _a[1], nemzetiseg = _a[2], nyeremeny = _a[3];
        return {
            helyezes: parseInt(helyezes),
            nev: nev,
            nemzetiseg: nemzetiseg,
            nyeremeny: parseInt(nyeremeny)
        };
    });
}
// Legnagyobb nyeremény visszaadó függvény
function LegtobbNyeremeny(vizsgaltObjektum) {
    return Math.max.apply(Math, vizsgaltObjektum.map(function (jatekos) { return jatekos.nyeremeny; }));
}
